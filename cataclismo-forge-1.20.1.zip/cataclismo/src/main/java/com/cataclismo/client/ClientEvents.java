package com.cataclismo.client;

import com.cataclismo.CataclismoMod;
import com.cataclismo.net.AcaoPacket;
import com.cataclismo.net.ModNetwork;
import com.cataclismo.power.PowerType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CataclismoMod.MODID, value = Dist.CLIENT)
public class ClientEvents {
    private static int poder = 0, habilidade = 0, mascara = 0;
    private static long recargaFimMs = 0;

    public static void atualizar(int p, int h, int m, int recargaTicks) {
        poder = p;
        habilidade = h;
        mascara = m;
        recargaFimMs = System.currentTimeMillis() + recargaTicks * 50L;
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        while (ClientKeys.USAR.consumeClick()) enviar(0);
        while (ClientKeys.PROXIMA.consumeClick()) enviar(1);
        while (ClientKeys.PODER.consumeClick()) enviar(2);
        while (ClientKeys.ANTERIOR.consumeClick()) enviar(3);
    }

    private static void enviar(int acao) {
        ModNetwork.CHANNEL.sendToServer(new AcaoPacket(acao));
    }

    @SubscribeEvent
    public static void hud(RenderGuiOverlayEvent.Post e) {
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        if (mascara == 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui) return;

        PowerType t = PowerType.de(poder);
        GuiGraphics g = e.getGuiGraphics();
        int x = 8;
        int y = e.getWindow().getGuiScaledHeight() - 58;
        int cor = 0xFF000000 | t.rgb;

        g.drawString(mc.font, "Poder: " + t.nome + "  [C]", x, y, cor, true);
        g.drawString(mc.font, "Habilidade " + (habilidade + 1) + "/5: " + t.habilidades[habilidade] + "  [V/Z]", x, y + 11, 0xFFFFFFFF, true);
        long resta = recargaFimMs - System.currentTimeMillis();
        if (resta > 0) {
            g.drawString(mc.font, String.format("Recarga: %.1fs", resta / 1000.0), x, y + 22, 0xFFFF5555, true);
        } else {
            g.drawString(mc.font, "PRONTO  [R] usar", x, y + 22, 0xFF55FF55, true);
        }
    }
}
