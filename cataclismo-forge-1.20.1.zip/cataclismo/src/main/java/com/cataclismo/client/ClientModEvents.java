package com.cataclismo.client;

import com.cataclismo.CataclismoMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CataclismoMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void teclas(RegisterKeyMappingsEvent e) {
        e.register(ClientKeys.USAR);
        e.register(ClientKeys.PROXIMA);
        e.register(ClientKeys.ANTERIOR);
        e.register(ClientKeys.PODER);
    }
}
