package com.cataclismo.client;

import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class ClientKeys {
    public static final String CATEGORIA = "key.categories.cataclismo";
    public static final KeyMapping USAR = new KeyMapping("key.cataclismo.usar", GLFW.GLFW_KEY_R, CATEGORIA);
    public static final KeyMapping PROXIMA = new KeyMapping("key.cataclismo.proxima", GLFW.GLFW_KEY_V, CATEGORIA);
    public static final KeyMapping ANTERIOR = new KeyMapping("key.cataclismo.anterior", GLFW.GLFW_KEY_Z, CATEGORIA);
    public static final KeyMapping PODER = new KeyMapping("key.cataclismo.poder", GLFW.GLFW_KEY_C, CATEGORIA);
}
