package com.cataclismo.net;

import com.cataclismo.CataclismoMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetwork {
    private static final String PROTOCOLO = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CataclismoMod.MODID, "main"),
            () -> PROTOCOLO, PROTOCOLO::equals, PROTOCOLO::equals);

    public static void register() {
        CHANNEL.registerMessage(0, AcaoPacket.class, AcaoPacket::encode, AcaoPacket::decode, AcaoPacket::handle);
        CHANNEL.registerMessage(1, EstadoPacket.class, EstadoPacket::encode, EstadoPacket::decode, EstadoPacket::handle);
    }
}
