package com.cataclismo.net;

import com.cataclismo.client.ClientEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: estado do HUD. */
public class EstadoPacket {
    private final int poder, habilidade, mascara, recarga;

    public EstadoPacket(int poder, int habilidade, int mascara, int recarga) {
        this.poder = poder;
        this.habilidade = habilidade;
        this.mascara = mascara;
        this.recarga = recarga;
    }

    public static void encode(EstadoPacket m, FriendlyByteBuf b) {
        b.writeInt(m.poder);
        b.writeInt(m.habilidade);
        b.writeInt(m.mascara);
        b.writeInt(m.recarga);
    }

    public static EstadoPacket decode(FriendlyByteBuf b) {
        return new EstadoPacket(b.readInt(), b.readInt(), b.readInt(), b.readInt());
    }

    public static void handle(EstadoPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientEvents.atualizar(m.poder, m.habilidade, m.mascara, m.recarga)));
        ctx.get().setPacketHandled(true);
    }
}
