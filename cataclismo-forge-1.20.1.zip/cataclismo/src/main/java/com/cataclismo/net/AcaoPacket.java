package com.cataclismo.net;

import com.cataclismo.power.PowerManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: 0 usar, 1 proxima habilidade, 2 proximo poder, 3 habilidade anterior. */
public class AcaoPacket {
    private final int acao;

    public AcaoPacket(int acao) { this.acao = acao; }

    public static void encode(AcaoPacket m, FriendlyByteBuf b) { b.writeByte(m.acao); }

    public static AcaoPacket decode(FriendlyByteBuf b) { return new AcaoPacket(b.readByte()); }

    public static void handle(AcaoPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) PowerManager.acao(p, m.acao);
        });
        ctx.get().setPacketHandled(true);
    }
}
