package com.cataclismo;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.IntPredicate;

/** Agendador simples: executa acoes a cada N ticks do servidor. */
@Mod.EventBusSubscriber(modid = CataclismoMod.MODID)
public final class Scheduler {
    private static final class Tarefa {
        final int vezes, intervalo;
        int espera, idx;
        final IntPredicate acao;

        Tarefa(int vezes, int intervalo, int atraso, IntPredicate acao) {
            this.vezes = vezes;
            this.intervalo = Math.max(1, intervalo);
            this.espera = atraso;
            this.acao = acao;
        }
    }

    private static final List<Tarefa> ATIVAS = new ArrayList<>();
    private static final List<Tarefa> NOVAS = new ArrayList<>();

    /** Executa 'acao' ate 'vezes' vezes, a cada 'intervalo' ticks. A acao recebe o indice e retorna true para cancelar. */
    public static void repetir(int vezes, int intervalo, IntPredicate acao) {
        NOVAS.add(new Tarefa(vezes, intervalo, 0, acao));
    }

    public static void depois(int atraso, Runnable r) {
        NOVAS.add(new Tarefa(1, 1, atraso, i -> { r.run(); return true; }));
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        if (!NOVAS.isEmpty()) {
            ATIVAS.addAll(NOVAS);
            NOVAS.clear();
        }
        Iterator<Tarefa> it = ATIVAS.iterator();
        while (it.hasNext()) {
            Tarefa t = it.next();
            if (t.espera > 0) { t.espera--; continue; }
            boolean fim;
            try {
                fim = t.acao.test(t.idx++);
            } catch (Throwable ex) {
                CataclismoMod.LOGGER.error("Erro em uma habilidade do Cataclismo", ex);
                fim = true;
            }
            if (fim || t.idx >= t.vezes) it.remove();
            else t.espera = t.intervalo - 1;
        }
    }

    @SubscribeEvent
    public static void parar(ServerStoppedEvent e) {
        ATIVAS.clear();
        NOVAS.clear();
        com.cataclismo.power.Abilities.INFINITO.clear();
    }
}
