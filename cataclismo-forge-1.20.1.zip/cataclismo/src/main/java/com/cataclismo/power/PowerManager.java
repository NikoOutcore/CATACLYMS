package com.cataclismo.power;

import com.cataclismo.CataclismoMod;
import com.cataclismo.Config;
import com.cataclismo.net.EstadoPacket;
import com.cataclismo.net.ModNetwork;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class PowerManager {
    private static final Map<UUID, long[]> RECARGAS = new HashMap<>();

    private static long[] arr(ServerPlayer p) {
        return RECARGAS.computeIfAbsent(p.getUUID(), k -> new long[PowerType.values().length * 5]);
    }

    public static int restante(ServerPlayer p, int poder, int hab) {
        long fim = arr(p)[poder * 5 + hab];
        return (int) Math.max(0, fim - p.level().getGameTime());
    }

    /** acao: 0 = usar, 1 = proxima habilidade, 2 = proximo poder, 3 = habilidade anterior */
    public static void acao(ServerPlayer p, int acao) {
        if (PowerData.mascara(p) == 0) {
            p.displayClientMessage(Component.literal("§cVocê ainda não tem nenhum poder. Procure as gemas nos meteoros!"), true);
            return;
        }
        switch (acao) {
            case 0 -> usar(p);
            case 1 -> PowerData.setHabilidade(p, (PowerData.habilidade(p) + 1) % 5);
            case 3 -> PowerData.setHabilidade(p, (PowerData.habilidade(p) + 4) % 5);
            case 2 -> {
                int atual = PowerData.poder(p);
                int n = PowerType.values().length;
                for (int k = 1; k <= n; k++) {
                    PowerType t = PowerType.de(atual + k);
                    if (PowerData.tem(p, t)) {
                        PowerData.setPoder(p, t.ordinal());
                        PowerData.setHabilidade(p, 0);
                        break;
                    }
                }
            }
            default -> { }
        }
        sincronizar(p);
    }

    private static void usar(ServerPlayer p) {
        PowerType t = PowerType.de(PowerData.poder(p));
        int ab = PowerData.habilidade(p);
        if (!PowerData.tem(p, t)) return;
        int rest = restante(p, t.ordinal(), ab);
        if (rest > 0) {
            p.displayClientMessage(Component.literal("§cRecarregando: " + String.format("%.1f", rest / 20.0) + "s"), true);
            return;
        }
        boolean ok;
        try {
            ok = Abilities.executar(p, t, ab);
        } catch (Throwable ex) {
            CataclismoMod.LOGGER.error("Falha ao usar habilidade", ex);
            ok = false;
        }
        if (ok) {
            long cd = p.isCreative() ? 0 : (long) (t.recarga[ab] * Config.MULT_RECARGA.get());
            arr(p)[t.ordinal() * 5 + ab] = p.level().getGameTime() + cd;
            p.displayClientMessage(Component.literal(t.cor + "§l" + t.habilidades[ab] + "!"), true);
        }
    }

    public static void sincronizar(ServerPlayer p) {
        int poder = PowerData.poder(p), hab = PowerData.habilidade(p);
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new EstadoPacket(poder, hab, PowerData.mascara(p), restante(p, poder, hab)));
    }
}
