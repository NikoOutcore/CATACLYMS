package com.cataclismo.power;

import com.cataclismo.Config;
import com.cataclismo.Scheduler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/** Todas as 25 habilidades. Cada metodo retorna true se a habilidade foi realmente usada (entra em recarga). */
public final class Abilities {
    private Abilities() {}

    /** UUID do jogador -> tick de jogo em que o Infinito termina. */
    public static final Map<UUID, Long> INFINITO = new HashMap<>();

    private record Alvo(Vec3 ponto, LivingEntity alvo) {}

    public static boolean executar(ServerPlayer p, PowerType t, int ab) {
        ServerLevel l = p.serverLevel();
        return switch (t) {
            case FOGO -> switch (ab) {
                case 0 -> bolaDeFogo(l, p);
                case 1 -> anelInfernal(l, p);
                case 2 -> chuvaDeMeteoros(l, p);
                case 3 -> explosaoSolar(l, p);
                default -> soproDoDragao(l, p);
            };
            case GELO -> switch (ab) {
                case 0 -> lancaDeGelo(l, p);
                case 1 -> nevasca(l, p);
                case 2 -> prisaoDeGelo(l, p);
                case 3 -> tempestadeDeEstacas(l, p);
                default -> zeroAbsoluto(l, p);
            };
            case RELAMPAGO -> switch (ab) {
                case 0 -> raioDivino(l, p);
                case 1 -> corrente(l, p);
                case 2 -> tempestadeEletrica(l, p);
                case 3 -> investida(l, p);
                default -> julgamentoDeZeus(l, p);
            };
            case GRAVIDADE -> switch (ab) {
                case 0 -> pulsoRepulsivo(l, p);
                case 1 -> ancora(l, p);
                case 2 -> esmagamento(l, p);
                case 3 -> ascensao(l, p);
                default -> buracoNegro(l, p);
            };
            case ILIMITADO -> switch (ab) {
                case 0 -> azul(l, p);
                case 1 -> vermelho(l, p);
                case 2 -> roxo(l, p);
                case 3 -> infinito(l, p);
                default -> dominio(l, p);
            };
        };
    }

    // =====================================================================
    //  FOGO
    // =====================================================================

    private static boolean bolaDeFogo(ServerLevel l, ServerPlayer p) {
        som(l, p.position(), SoundEvents.FIRECHARGE_USE);
        projetil(l, p, 2.2, 70, ParticleTypes.FLAME, false,
                pos -> {
                    par(l, ParticleTypes.LAVA, pos, 3, 0.4, 0);
                    par(l, ParticleTypes.LARGE_SMOKE, pos, 2, 0.3, 0.01);
                },
                pos -> {
                    explodir(l, p, pos, 7f, true);
                    for (LivingEntity e : vivos(l, p, pos, 9)) {
                        causar(l, p, e, 25);
                        e.setSecondsOnFire(10);
                    }
                });
        return true;
    }

    private static boolean anelInfernal(ServerLevel l, ServerPlayer p) {
        protect(p, 100);
        Vec3 c = p.position();
        Set<UUID> atingidos = new HashSet<>();
        som(l, c, SoundEvents.BLAZE_SHOOT);
        Scheduler.repetir(12, 2, i -> {
            double r = 3 + i * 1.8;
            anel(l, ParticleTypes.FLAME, c.add(0, 0.3, 0), r, (int) (r * 10));
            anel(l, ParticleTypes.LAVA, c.add(0, 0.5, 0), r, (int) (r * 3));
            for (LivingEntity e : vivos(l, p, c, r + 2)) {
                if (e.position().distanceTo(c) >= r - 2 && atingidos.add(e.getUUID())) {
                    causar(l, p, e, 22);
                    e.setSecondsOnFire(12);
                }
            }
            for (int k = 0; k < 2; k++) {
                double a = l.random.nextDouble() * Math.PI * 2;
                explodir(l, p, c.add(Math.cos(a) * r, 0.5, Math.sin(a) * r), 2.5f, true);
            }
            if (grief()) {
                for (int k = 0; k < (int) (r * 5); k++) {
                    double a = l.random.nextDouble() * Math.PI * 2;
                    incendiar(l, c.x + Math.cos(a) * r, c.y, c.z + Math.sin(a) * r);
                }
            }
            return false;
        });
        return true;
    }

    private static boolean chuvaDeMeteoros(ServerLevel l, ServerPlayer p) {
        Vec3 alvo = mirar(p, 70).ponto();
        som(l, p.position(), SoundEvents.ENDER_DRAGON_GROWL);
        Scheduler.repetir(28, 3, i -> {
            for (int k = 0; k < 2; k++) {
                double a = l.random.nextDouble() * Math.PI * 2;
                double d = l.random.nextDouble() * 16;
                Vec3 impacto = new Vec3(alvo.x + Math.cos(a) * d, alvo.y, alvo.z + Math.sin(a) * d);
                Vec3 inicio = new Vec3(impacto.x + 12, Math.min(impacto.y + 50, l.getMaxBuildHeight() - 2), impacto.z + 8);
                Vec3 dir = impacto.subtract(inicio).normalize();
                LargeFireball f = new LargeFireball(l, p, dir.x, dir.y, dir.z, grief() ? 5 : 1);
                f.setPos(inicio.x, inicio.y, inicio.z);
                l.addFreshEntity(f);
            }
            return false;
        });
        return true;
    }

    private static boolean explosaoSolar(ServerLevel l, ServerPlayer p) {
        protect(p, 100);
        som(l, p.position(), SoundEvents.BEACON_ACTIVATE);
        Scheduler.repetir(24, 1, i -> {
            if (!p.isAlive()) return true;
            double r = Math.max(1, 6 - i * 0.2);
            anel(l, ParticleTypes.FLAME, p.position().add(0, 0.2 + i * 0.12, 0), r, 24);
            par(l, ParticleTypes.END_ROD, p.position().add(0, 1, 0), 3, 0.5, 0.05);
            if (i == 23) {
                Vec3 q = p.position();
                explodir(l, p, q.add(0, 1, 0), 12f, true);
                for (LivingEntity e : vivos(l, p, q, 20)) {
                    causar(l, p, e, 70);
                    e.setSecondsOnFire(20);
                }
                par(l, ParticleTypes.EXPLOSION_EMITTER, q, 5, 3, 0);
            }
            return false;
        });
        return true;
    }

    private static boolean soproDoDragao(ServerLevel l, ServerPlayer p) {
        som(l, p.position(), SoundEvents.ENDER_DRAGON_SHOOT);
        Scheduler.repetir(40, 1, i -> {
            if (!p.isAlive()) return true;
            Vec3 o = p.getEyePosition().add(0, -0.3, 0);
            Vec3 d = p.getLookAngle();
            for (double k = 1.5; k <= 26; k += 1.0) {
                Vec3 q = o.add(d.scale(k));
                par(l, ParticleTypes.FLAME, q, 3, 0.2 + k * 0.04, 0.02);
                if (((int) k) % 6 == 0) par(l, ParticleTypes.LAVA, q, 2, 0.4, 0);
            }
            for (LivingEntity e : vivos(l, p, o.add(d.scale(14)), 18)) {
                Vec3 rel = e.getBoundingBox().getCenter().subtract(o);
                double ao = rel.dot(d);
                if (ao < 0 || ao > 28) continue;
                double perp = rel.subtract(d.scale(ao)).length();
                if (perp < 1.5 + ao * 0.18) {
                    causar(l, p, e, 5);
                    e.setSecondsOnFire(8);
                }
            }
            if (i % 4 == 0) explodir(l, p, o.add(d.scale(10 + l.random.nextInt(16))), 3f, true);
            if (i % 2 == 0) incendiar(l, o.x + d.x * 5, o.y + d.y * 5, o.z + d.z * 5);
            return false;
        });
        return true;
    }

    // =====================================================================
    //  GELO
    // =====================================================================

    private static boolean lancaDeGelo(ServerLevel l, ServerPlayer p) {
        Alvo a = mirar(p, 90);
        Vec3 q = a.ponto();
        som(l, p.position(), SoundEvents.GLASS_BREAK);
        linha(l, ParticleTypes.SNOWFLAKE, p.getEyePosition().add(0, -0.2, 0), q, 0.5);
        if (a.alvo() != null) {
            causar(l, p, a.alvo(), 45);
            congelar(a.alvo(), 200);
        }
        for (LivingEntity e : vivos(l, p, q, 5)) {
            causar(l, p, e, 20);
            congelar(e, 160);
        }
        par(l, ParticleTypes.ITEM_SNOWBALL, q, 60, 1.5, 0.2);
        estaca(l, BlockPos.containing(q), 7);
        congelarArea(l, q, 6);
        return true;
    }

    private static boolean nevasca(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        som(l, c, SoundEvents.PLAYER_HURT_FREEZE);
        congelarArea(l, c, 18);
        Scheduler.repetir(40, 2, i -> {
            if (!p.isAlive()) return true;
            for (int k = 0; k < 120; k++) {
                double a = l.random.nextDouble() * Math.PI * 2;
                double d = Math.sqrt(l.random.nextDouble()) * 18;
                par(l, ParticleTypes.SNOWFLAKE, c.add(Math.cos(a) * d, 1 + l.random.nextDouble() * 8, Math.sin(a) * d), 1, 0, 0);
            }
            for (LivingEntity e : vivos(l, p, c, 18)) {
                causar(l, p, e, 7);
                congelar(e, 60);
            }
            if (i % 4 == 0) {
                double a = l.random.nextDouble() * Math.PI * 2;
                double d = l.random.nextDouble() * 16;
                estaca(l, superficie(l, c.x + Math.cos(a) * d, c.z + Math.sin(a) * d), 4 + l.random.nextInt(4));
            }
            return false;
        });
        return true;
    }

    private static boolean prisaoDeGelo(ServerLevel l, ServerPlayer p) {
        Alvo a = mirar(p, 50);
        if (a.alvo() == null) {
            aviso(p, "Mire em uma criatura.");
            return false;
        }
        LivingEntity e = a.alvo();
        BlockPos b = e.blockPosition();
        int hw = Math.max(2, (int) Math.ceil(e.getBbWidth() / 2) + 1);
        int h = (int) Math.ceil(e.getBbHeight()) + 1;
        for (int dx = -hw; dx <= hw; dx++)
            for (int dz = -hw; dz <= hw; dz++)
                for (int dy = -1; dy <= h; dy++) {
                    boolean casca = Math.abs(dx) == hw || Math.abs(dz) == hw || dy == -1 || dy == h;
                    if (!casca) continue;
                    BlockPos q = b.offset(dx, dy, dz);
                    BlockState s = l.getBlockState(q);
                    if (s.isAir() || s.canBeReplaced()) {
                        l.setBlock(q, ((dx + dy + dz) % 2 == 0 ? Blocks.BLUE_ICE : Blocks.PACKED_ICE).defaultBlockState(), 2);
                    }
                }
        som(l, e.position(), SoundEvents.GLASS_BREAK);
        causar(l, p, e, 35);
        congelar(e, 300);
        for (LivingEntity o : vivos(l, p, e.position(), 5)) {
            congelar(o, 200);
            causar(l, p, o, 10);
        }
        Scheduler.repetir(10, 10, i -> {
            if (!e.isAlive()) return true;
            causar(l, p, e, 8);
            par(l, ParticleTypes.SNOWFLAKE, e.position().add(0, 1, 0), 20, 0.6, 0.05);
            return false;
        });
        return true;
    }

    private static boolean tempestadeDeEstacas(ServerLevel l, ServerPlayer p) {
        Vec3 alvo = mirar(p, 50).ponto();
        som(l, alvo, SoundEvents.GLASS_BREAK);
        Scheduler.repetir(25, 2, i -> {
            double a = l.random.nextDouble() * Math.PI * 2;
            double d = Math.sqrt(l.random.nextDouble()) * 10;
            BlockPos base = superficie(l, alvo.x + Math.cos(a) * d, alvo.z + Math.sin(a) * d);
            estaca(l, base, 6 + l.random.nextInt(4));
            Vec3 bc = Vec3.atBottomCenterOf(base);
            for (LivingEntity e : vivos(l, p, bc, 3)) {
                causar(l, p, e, 20);
                congelar(e, 100);
            }
            par(l, ParticleTypes.ITEM_SNOWBALL, bc.add(0, 1, 0), 25, 0.8, 0.2);
            som(l, bc, SoundEvents.GLASS_BREAK);
            return false;
        });
        return true;
    }

    private static boolean zeroAbsoluto(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        Set<UUID> atingidos = new HashSet<>();
        som(l, c, SoundEvents.BEACON_DEACTIVATE);
        Scheduler.repetir(16, 2, i -> {
            double r = 2 + i * 2;
            anel(l, ParticleTypes.SNOWFLAKE, c.add(0, 0.3, 0), r, (int) (r * 12));
            anel(l, ParticleTypes.SNOWFLAKE, c.add(0, 2, 0), r, (int) (r * 6));
            for (LivingEntity e : vivos(l, p, c, r + 3)) {
                if (e.position().distanceTo(c) >= r - 3 && atingidos.add(e.getUUID())) {
                    causar(l, p, e, 55);
                    congelar(e, 400);
                }
            }
            if (i == 15) congelarArea(l, c, 30);
            return false;
        });
        return true;
    }

    // =====================================================================
    //  RELAMPAGO
    // =====================================================================

    private static boolean raioDivino(ServerLevel l, ServerPlayer p) {
        Vec3 q = mirar(p, 120).ponto();
        protect(p, 40);
        raio(l, p, q);
        explodir(l, p, q, 4.5f, false);
        golpe(l, p, q, 6, 45);
        for (int k = 0; k < 3; k++) {
            raio(l, p, q.add((l.random.nextDouble() - 0.5) * 8, 0, (l.random.nextDouble() - 0.5) * 8));
        }
        return true;
    }

    private static boolean corrente(ServerLevel l, ServerPlayer p) {
        Alvo a = mirar(p, 60);
        LivingEntity inicio = a.alvo();
        if (inicio == null) {
            inicio = vivos(l, p, a.ponto(), 15).stream()
                    .min(Comparator.comparingDouble(e -> e.distanceToSqr(a.ponto()))).orElse(null);
        }
        if (inicio == null) {
            aviso(p, "Nenhum alvo por perto.");
            return false;
        }
        protect(p, 60);
        LivingEntity[] atual = {inicio};
        Set<UUID> visitados = new HashSet<>();
        Scheduler.repetir(14, 3, i -> {
            LivingEntity e = atual[0];
            if (e == null) return true;
            visitados.add(e.getUUID());
            Vec3 pos = e.position();
            raio(l, p, pos);
            causar(l, p, e, 30);
            explodir(l, p, pos, 2.5f, false);
            atual[0] = vivos(l, p, pos, 14).stream()
                    .filter(x -> !visitados.contains(x.getUUID()))
                    .min(Comparator.comparingDouble(x -> x.distanceToSqr(pos))).orElse(null);
            return false;
        });
        return true;
    }

    private static boolean tempestadeEletrica(ServerLevel l, ServerPlayer p) {
        Alvo a = mirar(p, 60);
        Vec3 c = a.ponto();
        protect(p, 100);
        l.setWeatherParameters(0, 2400, true, true);
        Scheduler.repetir(40, 2, i -> {
            double ang = l.random.nextDouble() * Math.PI * 2;
            double d = Math.sqrt(l.random.nextDouble()) * 18;
            Vec3 q = chao(l, c.x + Math.cos(ang) * d, c.z + Math.sin(ang) * d);
            raio(l, p, q);
            golpe(l, p, q, 3, 15);
            return false;
        });
        return true;
    }

    private static boolean investida(ServerLevel l, ServerPlayer p) {
        protect(p, 60);
        Vec3 o = p.getEyePosition();
        Vec3 d = p.getLookAngle();
        Vec3 fim = o.add(d.scale(32));
        BlockHitResult bh = l.clip(new ClipContext(o, fim, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (bh.getType() != HitResult.Type.MISS) fim = bh.getLocation().subtract(d.scale(1.5));
        double len = fim.subtract(o).length();
        Set<UUID> atingidos = new HashSet<>();
        for (double k = 0; k <= len; k += 1.5) {
            Vec3 q = o.add(d.scale(k));
            par(l, ParticleTypes.ELECTRIC_SPARK, q, 8, 0.4, 0.1);
            for (LivingEntity e : vivos(l, p, q, 3.5)) {
                if (atingidos.add(e.getUUID())) {
                    raio(l, p, e.position());
                    causar(l, p, e, 40);
                }
            }
        }
        raio(l, p, p.position());
        p.teleportTo(fim.x, fim.y - p.getEyeHeight(), fim.z);
        p.fallDistance = 0;
        raio(l, p, p.position());
        explodir(l, p, p.position(), 4f, false);
        return true;
    }

    private static boolean julgamentoDeZeus(ServerLevel l, ServerPlayer p) {
        protect(p, 300);
        l.setWeatherParameters(0, 3600, true, true);
        som(l, p.position(), SoundEvents.LIGHTNING_BOLT_THUNDER);
        Scheduler.repetir(70, 2, i -> {
            if (!p.isAlive()) return true;
            Vec3 c = p.position();
            for (int k = 0; k < 2; k++) {
                double ang = l.random.nextDouble() * Math.PI * 2;
                double d = 7 + l.random.nextDouble() * 23;
                Vec3 q = chao(l, c.x + Math.cos(ang) * d, c.z + Math.sin(ang) * d);
                raio(l, p, q);
                golpe(l, p, q, 4, 25);
                if (i % 2 == 0) explodir(l, p, q, 3.5f, false);
            }
            vivos(l, p, c, 32).stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(c))).ifPresent(e -> {
                raio(l, p, e.position());
                causar(l, p, e, 30);
            });
            return false;
        });
        return true;
    }

    // =====================================================================
    //  GRAVIDADE
    // =====================================================================

    private static boolean pulsoRepulsivo(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        Vec3 olhar = p.getLookAngle();
        som(l, c, SoundEvents.WARDEN_SONIC_BOOM);
        Scheduler.repetir(8, 1, i -> {
            anel(l, ParticleTypes.REVERSE_PORTAL, c.add(0, 1, 0), 2 + i * 3, 60);
            return false;
        });
        for (Entity e : todas(l, p, c, 28)) {
            impulso(e, e.position().subtract(c), 4.5, 1.0);
            if (e instanceof LivingEntity le) causar(l, p, le, 20);
        }
        esfera(l, c.add(olhar.scale(5)), 4);
        esfera(l, c.add(olhar.scale(10)), 5);
        esfera(l, c.add(olhar.scale(16)), 6);
        return true;
    }

    private static boolean ancora(ServerLevel l, ServerPlayer p) {
        Vec3 c = mirar(p, 40).ponto().add(0, 1, 0);
        som(l, c, SoundEvents.BEACON_POWER_SELECT);
        Scheduler.repetir(40, 1, i -> {
            for (Entity e : todas(l, p, c, 20)) {
                Vec3 v = c.subtract(e.position());
                double d = v.length();
                impulso(e, v, Math.min(1.6, 0.5 + (20 - d) * 0.06), 0);
                if (i % 5 == 0 && e instanceof LivingEntity le && d < 6) causar(l, p, le, 6);
            }
            par(l, ParticleTypes.PORTAL, c, 30, 2, 0.5);
            if (i % 10 == 0) esfera(l, c, 3);
            if (i == 39) explodir(l, p, c, 5f, false);
            return false;
        });
        return true;
    }

    private static boolean esmagamento(ServerLevel l, ServerPlayer p) {
        Vec3 c = mirar(p, 50).ponto();
        som(l, c, SoundEvents.GENERIC_EXPLODE);
        for (LivingEntity e : vivos(l, p, c, 8)) {
            causar(l, p, e, 60);
            impulso(e, new Vec3(0, -1, 0), 4, 0);
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 5));
        }
        esfera(l, c.add(0, -1, 0), 7);
        par(l, ParticleTypes.EXPLOSION_EMITTER, c, 6, 3, 0);
        anel(l, ParticleTypes.REVERSE_PORTAL, c.add(0, 0.5, 0), 6, 80);
        return true;
    }

    private static boolean ascensao(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        List<LivingEntity> alvos = vivos(l, p, c, 22);
        if (alvos.isEmpty()) {
            aviso(p, "Nenhuma criatura por perto.");
            return false;
        }
        som(l, c, SoundEvents.BEACON_ACTIVATE);
        for (LivingEntity e : alvos) {
            e.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 50, 9));
            impulso(e, new Vec3(0, 1, 0), 2.5, 0);
            causar(l, p, e, 5);
        }
        Scheduler.depois(52, () -> {
            for (LivingEntity e : alvos) {
                if (!e.isAlive()) continue;
                impulso(e, new Vec3(0, -1, 0), 5, 0);
                causar(l, p, e, 30);
            }
        });
        return true;
    }

    private static boolean buracoNegro(ServerLevel l, ServerPlayer p) {
        Vec3 c = mirar(p, 60).ponto().add(0, 4, 0);
        DustParticleOptions preto = new DustParticleOptions(new Vector3f(0f, 0f, 0f), 4f);
        som(l, c, SoundEvents.END_PORTAL_SPAWN);
        Scheduler.repetir(100, 2, i -> {
            double r = 2.5 + i * 0.09;
            esfera(l, c, (int) r);
            par(l, preto, c, 40, r * 0.4, 0);
            anel(l, ParticleTypes.PORTAL, c, r + 1, 30);
            anel(l, ParticleTypes.SMOKE, c, r + 3, 30);
            for (Entity e : todas(l, p, c, 32)) {
                Vec3 v = c.subtract(e.position());
                double d = Math.max(v.length(), 0.5);
                if (!(e instanceof LivingEntity) && d < r + 1) {
                    e.discard();
                    continue;
                }
                impulso(e, v, Math.min(2.0, 3.5 / Math.sqrt(d) + 0.3), 0);
                e.fallDistance = 0;
                if (e instanceof LivingEntity le && d < r + 3) causar(l, p, le, 12);
            }
            if (i == 99) {
                explodir(l, p, c, 8f, false);
                par(l, ParticleTypes.EXPLOSION_EMITTER, c, 6, 4, 0);
            }
            return false;
        });
        return true;
    }

    // =====================================================================
    //  ILIMITADO (Satoru Gojo)
    // =====================================================================

    private static boolean azul(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.getEyePosition().add(p.getLookAngle().scale(9));
        DustParticleOptions azul = new DustParticleOptions(new Vector3f(0.15f, 0.45f, 1f), 3f);
        som(l, c, SoundEvents.BEACON_POWER_SELECT);
        Scheduler.repetir(30, 1, i -> {
            if (!p.isAlive()) return true;
            par(l, azul, c, 25, 1.2, 0);
            for (Entity e : todas(l, p, c, 16)) {
                Vec3 v = c.subtract(e.position());
                impulso(e, v, 1.2, 0);
                if (e instanceof LivingEntity le && v.length() < 4) causar(l, p, le, 10);
            }
            if (i % 3 == 0) esfera(l, c, 3);
            if (i == 29) explodir(l, p, c, 4f, false);
            return false;
        });
        return true;
    }

    private static boolean vermelho(ServerLevel l, ServerPlayer p) {
        Vec3 q = mirar(p, 60).ponto();
        DustParticleOptions vermelho = new DustParticleOptions(new Vector3f(1f, 0.1f, 0.1f), 3f);
        protect(p, 40);
        Scheduler.repetir(10, 1, i -> {
            par(l, vermelho, q, 40, 1.5, 0.1);
            if (i == 9) {
                explodir(l, p, q, 9f, false);
                for (Entity e : todas(l, p, q, 16)) {
                    impulso(e, e.position().subtract(q), 5, 0.6);
                    if (e instanceof LivingEntity le) causar(l, p, le, 70);
                }
            }
            return false;
        });
        return true;
    }

    private static boolean roxo(ServerLevel l, ServerPlayer p) {
        protect(p, 120);
        DustParticleOptions azul = new DustParticleOptions(new Vector3f(0.15f, 0.45f, 1f), 2f);
        DustParticleOptions verm = new DustParticleOptions(new Vector3f(1f, 0.1f, 0.1f), 2f);
        DustParticleOptions roxo = new DustParticleOptions(new Vector3f(0.6f, 0.1f, 1f), 4f);
        som(l, p.position(), SoundEvents.BEACON_ACTIVATE);
        Scheduler.repetir(30, 1, i -> {
            if (!p.isAlive()) return true;
            Vec3 dir = p.getLookAngle();
            Vec3 c = p.getEyePosition().add(dir.scale(3));
            Vec3 lado = Math.abs(dir.y) > 0.98 ? new Vec3(1, 0, 0) : dir.cross(new Vec3(0, 1, 0)).normalize();
            double sep = 2.5 * (1 - i / 30.0);
            par(l, azul, c.add(lado.scale(sep)), 6, 0.15, 0);
            par(l, verm, c.subtract(lado.scale(sep)), 6, 0.15, 0);
            if (i == 29) {
                som(l, c, SoundEvents.WARDEN_SONIC_BOOM);
                Vec3[] pos = {c};
                Set<UUID> atingidos = new HashSet<>();
                Scheduler.repetir(40, 1, j -> {
                    Vec3 q = pos[0];
                    pos[0] = q.add(dir.scale(2.5));
                    par(l, roxo, q, 30, 1.5, 0.05);
                    par(l, ParticleTypes.PORTAL, q, 20, 2, 0.5);
                    esfera(l, q, 4);
                    for (LivingEntity e : vivos(l, p, q, 6)) {
                        if (atingidos.add(e.getUUID())) causar(l, p, e, 120);
                    }
                    if (j == 39) explodir(l, p, q, 6f, false);
                    return false;
                });
            }
            return false;
        });
        return true;
    }

    private static boolean infinito(ServerLevel l, ServerPlayer p) {
        INFINITO.put(p.getUUID(), l.getGameTime() + 300);
        protect(p, 300);
        som(l, p.position(), SoundEvents.BEACON_POWER_SELECT);
        Scheduler.repetir(150, 2, i -> {
            if (!p.isAlive()) return true;
            Vec3 c = p.position().add(0, 1, 0);
            anel(l, ParticleTypes.END_ROD, c, 3.5, 20);
            anel(l, ParticleTypes.END_ROD, c.add(0, 0.8, 0), 3.0, 14);
            for (Entity e : todas(l, p, c, 5)) {
                impulso(e, e.position().subtract(c), 1.1, 0.15);
            }
            return false;
        });
        return true;
    }

    private static boolean dominio(ServerLevel l, ServerPlayer p) {
        Vec3 c = p.position();
        protect(p, 220);
        DustParticleOptions preto = new DustParticleOptions(new Vector3f(0.02f, 0.02f, 0.05f), 3f);
        som(l, c, SoundEvents.END_PORTAL_SPAWN);
        Scheduler.repetir(100, 2, i -> {
            if (!p.isAlive()) return true;
            for (int k = 0; k < 80; k++) {
                Vec3 v = new Vec3(l.random.nextGaussian(), l.random.nextGaussian(), l.random.nextGaussian()).normalize().scale(22);
                par(l, k % 2 == 0 ? preto : ParticleTypes.END_ROD, c.add(v), 1, 0, 0);
            }
            for (LivingEntity e : vivos(l, p, c, 22)) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 9));
                e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 3));
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 40, 4));
                e.setDeltaMovement(0, 0, 0);
                e.hurtMarked = true;
                causar(l, p, e, 3);
            }
            return false;
        });
        return true;
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    private static boolean grief() { return Config.DESTRUIR_BLOCOS.get(); }

    private static float dano(double v) { return (float) (v * Config.MULT_DANO.get()); }

    private static DamageSource fonte(ServerLevel l, ServerPlayer p) { return l.damageSources().indirectMagic(p, p); }

    private static void causar(ServerLevel l, ServerPlayer p, LivingEntity e, double v) {
        e.invulnerableTime = 0;
        e.hurt(fonte(l, p), dano(v));
    }

    private static void protect(ServerPlayer p, int ticks) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, ticks, 4, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, ticks, 0, false, false));
    }

    private static void aviso(ServerPlayer p, String msg) {
        p.displayClientMessage(Component.literal("§c" + msg), true);
    }

    private static void som(ServerLevel l, Vec3 v, SoundEvent s) {
        l.playSound(null, v.x, v.y, v.z, s, SoundSource.PLAYERS, 2f, 1f);
    }

    private static void par(ServerLevel l, ParticleOptions o, Vec3 v, int n, double espalhar, double vel) {
        l.sendParticles(o, v.x, v.y, v.z, n, espalhar, espalhar, espalhar, vel);
    }

    private static void anel(ServerLevel l, ParticleOptions o, Vec3 c, double r, int n) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            l.sendParticles(o, c.x + Math.cos(a) * r, c.y, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    private static void linha(ServerLevel l, ParticleOptions o, Vec3 a, Vec3 b, double passo) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 u = d.scale(1 / len);
        for (double k = 0; k <= len; k += passo) par(l, o, a.add(u.scale(k)), 1, 0, 0);
    }

    private static void impulso(Entity e, Vec3 dir, double forca, double y) {
        e.setDeltaMovement(dir.normalize().scale(forca).add(0, y, 0));
        e.hurtMarked = true;
    }

    private static List<LivingEntity> vivos(ServerLevel l, ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        return l.getEntitiesOfClass(LivingEntity.class, box, e -> e != p && e.isAlive() && !e.isSpectator()
                && e.distanceToSqr(c) <= r * r
                && !(e instanceof TamableAnimal ta && ta.isOwnedBy(p)));
    }

    private static List<Entity> todas(ServerLevel l, ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        return l.getEntitiesOfClass(Entity.class, box, e -> e != p && e.isAlive() && !e.isSpectator()
                && !(e instanceof LightningBolt)
                && e.distanceToSqr(c) <= r * r
                && !(e instanceof TamableAnimal ta && ta.isOwnedBy(p)));
    }

    private static void golpe(ServerLevel l, ServerPlayer p, Vec3 c, double r, double v) {
        for (LivingEntity e : vivos(l, p, c, r)) causar(l, p, e, v);
    }

    private static Alvo mirar(ServerPlayer p, double alcance) {
        ServerLevel l = p.serverLevel();
        Vec3 olho = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        Vec3 fim = olho.add(dir.scale(alcance));
        BlockHitResult bh = l.clip(new ClipContext(olho, fim, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 limite = bh.getType() == HitResult.Type.MISS ? fim : bh.getLocation();
        AABB box = p.getBoundingBox().expandTowards(dir.scale(alcance)).inflate(1.0);
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(l, p, olho, limite, box,
                e -> !e.isSpectator() && e.isPickable() && e instanceof LivingEntity);
        if (eh != null) return new Alvo(eh.getLocation(), (LivingEntity) eh.getEntity());
        return new Alvo(limite, null);
    }

    private static BlockPos superficie(ServerLevel l, double x, double z) {
        return l.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.containing(x, 0, z));
    }

    private static Vec3 chao(ServerLevel l, double x, double z) {
        BlockPos b = superficie(l, x, z);
        return new Vec3(x, b.getY(), z);
    }

    /** Projetil invisivel que anda 'vel' blocos por tick. */
    private static void projetil(ServerLevel l, ServerPlayer p, double vel, int maxTicks, ParticleOptions part,
                                 boolean atravessa, Consumer<Vec3> passo, Consumer<Vec3> impacto) {
        Vec3 dir = p.getLookAngle().normalize();
        Vec3[] pos = {p.getEyePosition().add(dir.scale(1.5))};
        Scheduler.repetir(maxTicks, 1, i -> {
            Vec3 atual = pos[0];
            Vec3 prox = atual.add(dir.scale(vel));
            if (!atravessa) {
                BlockHitResult bh = l.clip(new ClipContext(atual, prox, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                if (bh.getType() != HitResult.Type.MISS) {
                    impacto.accept(bh.getLocation());
                    return true;
                }
                if (!vivos(l, p, prox, 1.6).isEmpty()) {
                    impacto.accept(prox);
                    return true;
                }
            }
            pos[0] = prox;
            par(l, part, prox, 6, 0.25, 0.02);
            passo.accept(prox);
            if (!atravessa && i == maxTicks - 1) impacto.accept(prox);
            return false;
        });
    }

    private static void explodir(ServerLevel l, ServerPlayer p, Vec3 c, float r, boolean fogo) {
        if (p.position().distanceTo(c) < r * 2 + 2) protect(p, 40);
        l.explode(p, c.x, c.y, c.z, r, fogo, grief() ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
    }

    private static void raio(ServerLevel l, ServerPlayer p, Vec3 pos) {
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(l);
        if (b == null) return;
        b.moveTo(pos.x, pos.y, pos.z);
        b.setCause(p);
        l.addFreshEntity(b);
    }

    private static void congelar(LivingEntity e, int ticks) {
        e.setTicksFrozen(e.getTicksRequiredToFreeze() + ticks);
        e.setRemainingFireTicks(0);
        e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 6));
        e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 2));
    }

    /** Remove todos os blocos (exceto indestrutiveis) numa esfera. */
    private static void esfera(ServerLevel l, Vec3 c, int r) {
        if (!grief()) return;
        BlockPos cp = BlockPos.containing(c);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int x = -r; x <= r; x++)
            for (int y = -r; y <= r; y++)
                for (int z = -r; z <= r; z++) {
                    if (x * x + y * y + z * z > r * r) continue;
                    m.set(cp.getX() + x, cp.getY() + y, cp.getZ() + z);
                    if (m.getY() < l.getMinBuildHeight() || m.getY() >= l.getMaxBuildHeight()) continue;
                    BlockState s = l.getBlockState(m);
                    if (s.isAir() || s.getDestroySpeed(l, m) < 0) continue;
                    l.setBlock(m, Blocks.AIR.defaultBlockState(), 2);
                }
    }

    private static void incendiar(ServerLevel l, double x, double y, double z) {
        if (!grief()) return;
        BlockPos b = BlockPos.containing(x, y, z);
        for (int dy = 3; dy >= -4; dy--) {
            BlockPos q = b.above(dy);
            if (l.getBlockState(q).isAir() && Blocks.FIRE.defaultBlockState().canSurvive(l, q)) {
                l.setBlockAndUpdate(q, Blocks.FIRE.defaultBlockState());
                return;
            }
        }
    }

    private static void estaca(ServerLevel l, BlockPos base, int h) {
        for (int y = 0; y < h; y++) {
            int r = y < h / 3 ? 1 : 0;
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dz * dz > r * r) continue;
                    BlockPos q = base.offset(dx, y, dz);
                    BlockState s = l.getBlockState(q);
                    if (s.isAir() || s.canBeReplaced()) {
                        l.setBlock(q, (y % 2 == 0 ? Blocks.BLUE_ICE : Blocks.PACKED_ICE).defaultBlockState(), 2);
                    }
                }
        }
    }

    /** Transforma a superficie em gelo: agua vira gelo, terreno vira gelo compacto com neve por cima. */
    private static void congelarArea(ServerLevel l, Vec3 c, int r) {
        if (!grief()) return;
        BlockPos cp = BlockPos.containing(c);
        for (int x = -r; x <= r; x++)
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z > r * r) continue;
                BlockPos topo = l.getHeightmapPos(Heightmap.Types.WORLD_SURFACE, cp.offset(x, 0, z));
                BlockPos s = topo.below();
                if (Math.abs(s.getY() - cp.getY()) > 14) continue;
                BlockState st = l.getBlockState(s);
                if (st.getFluidState().is(FluidTags.WATER)) {
                    l.setBlock(s, Blocks.ICE.defaultBlockState(), 2);
                } else if (st.is(BlockTags.LEAVES)) {
                    l.setBlock(s, Blocks.SNOW_BLOCK.defaultBlockState(), 2);
                } else if (!st.isAir() && st.getDestroySpeed(l, s) >= 0) {
                    l.setBlock(s, (l.random.nextInt(3) == 0 ? Blocks.BLUE_ICE : Blocks.PACKED_ICE).defaultBlockState(), 2);
                    if (l.getBlockState(topo).isAir()) l.setBlock(topo, Blocks.SNOW.defaultBlockState(), 2);
                }
            }
    }
}
