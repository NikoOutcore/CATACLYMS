package com.cataclismo.power;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

/** Guarda os poderes do jogador no NBT persistente dele. */
public final class PowerData {
    private static final String KEY = "cataclismo";

    private static CompoundTag raiz(Player p) {
        CompoundTag r = p.getPersistentData();
        if (!r.contains(KEY, 10)) r.put(KEY, new CompoundTag());
        return r.getCompound(KEY);
    }

    public static int mascara(Player p) { return raiz(p).getInt("mask"); }

    public static boolean tem(Player p, PowerType t) { return ((mascara(p) >> t.ordinal()) & 1) == 1; }

    public static void desbloquear(Player p, PowerType t) {
        CompoundTag c = raiz(p);
        c.putInt("mask", c.getInt("mask") | (1 << t.ordinal()));
        c.putInt("power", t.ordinal());
        c.putInt("ability", 0);
    }

    public static int poder(Player p) { return raiz(p).getInt("power"); }
    public static int habilidade(Player p) { return raiz(p).getInt("ability"); }
    public static void setPoder(Player p, int i) { raiz(p).putInt("power", i); }
    public static void setHabilidade(Player p, int i) { raiz(p).putInt("ability", i); }

    public static void copiar(Player de, Player para) {
        para.getPersistentData().put(KEY, de.getPersistentData().getCompound(KEY).copy());
    }
}
