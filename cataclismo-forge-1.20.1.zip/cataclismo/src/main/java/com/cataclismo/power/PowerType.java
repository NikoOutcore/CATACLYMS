package com.cataclismo.power;

import net.minecraft.ChatFormatting;

public enum PowerType {
    FOGO("fogo", "Fogo", ChatFormatting.GOLD, 0xFF6A00,
            new String[]{"Bola de Fogo Colossal", "Anel Infernal", "Chuva de Meteoros", "Explosão Solar", "Sopro do Dragão"},
            new int[]{80, 160, 400, 500, 300}),
    GELO("gelo", "Gelo", ChatFormatting.AQUA, 0x7FD7FF,
            new String[]{"Lança de Gelo Perfurante", "Nevasca Devastadora", "Prisão de Gelo", "Tempestade de Estacas", "Zero Absoluto"},
            new int[]{80, 240, 200, 300, 600}),
    RELAMPAGO("relampago", "Relâmpago", ChatFormatting.YELLOW, 0xFFE93B,
            new String[]{"Raio Divino", "Corrente de Relâmpagos", "Tempestade Elétrica", "Investida do Trovão", "Julgamento de Zeus"},
            new int[]{60, 160, 400, 100, 800}),
    GRAVIDADE("gravidade", "Gravidade", ChatFormatting.DARK_PURPLE, 0x9B4DFF,
            new String[]{"Pulso Repulsivo", "Âncora Gravitacional", "Esmagamento", "Ascensão Gravitacional", "Buraco Negro"},
            new int[]{120, 200, 240, 300, 800}),
    ILIMITADO("ilimitado", "Ilimitado", ChatFormatting.BLUE, 0x6FB6FF,
            new String[]{"Azul: Convergência", "Vermelho: Repulsão", "Roxo Imaginário", "Infinito", "Expansão de Domínio: Vazio Imensurável"},
            new int[]{100, 120, 700, 600, 1200});

    public final String id;
    public final String nome;
    public final ChatFormatting cor;
    public final int rgb;
    public final String[] habilidades;
    public final int[] recarga; // em ticks

    PowerType(String id, String nome, ChatFormatting cor, int rgb, String[] habilidades, int[] recarga) {
        this.id = id;
        this.nome = nome;
        this.cor = cor;
        this.rgb = rgb;
        this.habilidades = habilidades;
        this.recarga = recarga;
    }

    public static PowerType de(int i) {
        PowerType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
