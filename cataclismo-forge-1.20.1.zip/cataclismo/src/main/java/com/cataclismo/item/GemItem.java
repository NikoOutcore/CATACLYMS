package com.cataclismo.item;

import com.cataclismo.power.PowerData;
import com.cataclismo.power.PowerManager;
import com.cataclismo.power.PowerType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

public class GemItem extends Item {
    private final PowerType poder;

    public GemItem(PowerType poder) {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
        this.poder = poder;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (PowerData.tem(sp, poder)) {
                sp.displayClientMessage(Component.literal("§cVocê já possui o poder " + poder.nome + "."), true);
                return InteractionResultHolder.fail(stack);
            }
            PowerData.desbloquear(sp, poder);
            PowerManager.sincronizar(sp);
            var sl = sp.serverLevel();
            sl.playSound(null, sp.blockPosition(), SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 1.0f, 1.5f);
            sl.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1, sp.getZ(), 80, 0.6, 1.0, 0.6, 0.2);
            sp.getServer().getPlayerList().broadcastSystemMessage(
                    Component.literal("§l" + poder.cor + sp.getName().getString() + " absorveu o poder do " + poder.nome + "!"), false);
            if (!sp.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("§7Botão direito para absorver o poder."));
        for (int i = 0; i < 5; i++) {
            tip.add(Component.literal(poder.cor + " " + (i + 1) + ". " + poder.habilidades[i]));
        }
    }
}
