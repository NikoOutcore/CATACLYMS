package com.cataclismo.item;

import com.cataclismo.CataclismoMod;
import com.cataclismo.power.PowerType;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, CataclismoMod.MODID);
    public static final Map<PowerType, RegistryObject<Item>> GEMS = new EnumMap<>(PowerType.class);

    static {
        for (PowerType t : PowerType.values()) {
            GEMS.put(t, ITEMS.register("gema_" + t.id, () -> new GemItem(t)));
        }
    }
}
