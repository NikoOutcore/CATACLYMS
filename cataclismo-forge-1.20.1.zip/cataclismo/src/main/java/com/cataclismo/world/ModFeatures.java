package com.cataclismo.world;

import com.cataclismo.CataclismoMod;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, CataclismoMod.MODID);

    public static final RegistryObject<MeteoroFeature> METEORO = FEATURES.register("meteoro", MeteoroFeature::new);
}
