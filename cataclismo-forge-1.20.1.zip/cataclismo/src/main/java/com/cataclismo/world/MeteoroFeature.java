package com.cataclismo.world;

import com.cataclismo.CataclismoMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Cria uma cratera de meteoro com um bau no fundo contendo uma gema de poder. */
public class MeteoroFeature extends Feature<NoneFeatureConfiguration> {

    public MeteoroFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    private static Block revestimento(RandomSource r) {
        int n = r.nextInt(100);
        if (n < 45) return Blocks.BLACKSTONE;
        if (n < 70) return Blocks.MAGMA_BLOCK;
        if (n < 85) return Blocks.OBSIDIAN;
        if (n < 95) return Blocks.CRYING_OBSIDIAN;
        return Blocks.TUFF;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        RandomSource rnd = ctx.random();
        BlockPos origem = ctx.origin();

        // nada de meteoro no oceano
        if (!level.getFluidState(origem.below()).isEmpty()) return false;

        int r = 4 + rnd.nextInt(3);
        BlockPos centro = origem.below(2);

        for (int dx = -r - 2; dx <= r + 2; dx++) {
            for (int dz = -r - 2; dz <= r + 2; dz++) {
                for (int dy = -r - 2; dy <= r; dy++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    BlockPos p = centro.offset(dx, dy, dz);
                    if (d <= r - 1) {
                        level.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
                    } else if (d <= r + 1 && dy <= 1) {
                        BlockState atual = level.getBlockState(p);
                        if (!atual.isAir()) {
                            level.setBlock(p, revestimento(rnd).defaultBlockState(), 2);
                        }
                    }
                }
            }
        }

        // brasas na borda do fundo
        for (int i = 0; i < 6; i++) {
            BlockPos f = centro.offset(rnd.nextInt(5) - 2, -(r - 1), rnd.nextInt(5) - 2);
            if (level.getBlockState(f).isAir() && level.getBlockState(f.below()).isSolid()) {
                level.setBlock(f, Blocks.FIRE.defaultBlockState(), 2);
            }
        }

        // bau com a gema
        BlockPos bau = centro.offset(0, -(r - 1), 0);
        level.setBlock(bau.below(), Blocks.MAGMA_BLOCK.defaultBlockState(), 2);
        level.setBlock(bau, Blocks.CHEST.defaultBlockState()
                .setValue(ChestBlock.FACING, Direction.Plane.HORIZONTAL.getRandomDirection(rnd)), 2);
        RandomizableContainerBlockEntity.setLootTable(level, rnd, bau,
                new ResourceLocation(CataclismoMod.MODID, "chests/meteoro"));
        return true;
    }
}
