package com.cataclismo;

import com.cataclismo.power.Abilities;
import com.cataclismo.power.PowerData;
import com.cataclismo.power.PowerManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CataclismoMod.MODID)
public class ModEvents {

    /** Mantem os poderes depois da morte. */
    @SubscribeEvent
    public static void clonar(PlayerEvent.Clone e) {
        PowerData.copiar(e.getOriginal(), e.getEntity());
    }

    @SubscribeEvent
    public static void entrou(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) PowerManager.sincronizar(sp);
    }

    @SubscribeEvent
    public static void renasceu(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) PowerManager.sincronizar(sp);
    }

    /** Infinito: enquanto ativo, nada encosta no jogador. */
    @SubscribeEvent
    public static void ataque(LivingAttackEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            Long fim = Abilities.INFINITO.get(p.getUUID());
            if (fim != null && p.level().getGameTime() < fim
                    && !e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                e.setCanceled(true);
            }
        }
    }
}
