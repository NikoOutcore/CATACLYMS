package com.cataclismo;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue DESTRUIR_BLOCOS = B
            .comment("Se false, os poderes causam dano mas NAO destroem blocos.")
            .define("destruirBlocos", true);
    public static final ForgeConfigSpec.DoubleValue MULT_DANO = B
            .comment("Multiplicador do dano de todas as habilidades.")
            .defineInRange("multiplicadorDano", 1.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue MULT_RECARGA = B
            .comment("Multiplicador do tempo de recarga das habilidades (0 = sem recarga).")
            .defineInRange("multiplicadorRecarga", 1.0, 0.0, 100.0);

    public static final ForgeConfigSpec SPEC = B.build();
}
